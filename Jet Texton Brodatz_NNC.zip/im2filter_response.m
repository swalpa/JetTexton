function [ filter_response ] = im2filter_response( image_name,patch_width,patch_height,filter,options)

%image_name
training_im = get_image(image_name,patch_width,patch_height,options);

filter_response = zeros(size(training_im,1)*size(training_im,2),5);

%var=[1*.5 2*.5 4*.5];
%filter_responseTotal=[];
%for i=1:length(var)
sigma=0.5;  % best sigma=0.5;
jet = computeBIFs(training_im, sigma, 0);
jet = jet(:,:,2:6);
filter_response1=jet(:);
filter_response(:,1:5)=reshape(filter_response1,[size(training_im,1)*size(training_im,2),5]);

%%%%%%%%%%LOg Of Gausian%%%%%%%%%%%
SUP=length(-5*sigma:5*sigma);  
F(:,:)=fspecial('log',SUP,sigma);
tmp = conv2(double(training_im),F(:,:),'same');
filter_response(:,6)=tmp(:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

% for k=1:size(filter,3)
%     tmp = conv2(double(training_im ),filter(:,:,k),'same');
%     filter_response(:,k)=tmp(:);
% end;
% if strfind(options, 'MR8')
%     filter_response_MR8 = zeros(size(training_im,1)*size(training_im,2),8);
%     filter_response_MR8(:,1) = max(filter_response(:,1:6),[],2);
%     filter_response_MR8(:,2) = max(filter_response(:,7:12),[],2);
%     filter_response_MR8(:,3) = max(filter_response(:,13:18),[],2);
%     filter_response_MR8(:,4) = max(filter_response(:,19:24),[],2);
%     filter_response_MR8(:,5) = max(filter_response(:,25:30),[],2);
%     filter_response_MR8(:,6) = max(filter_response(:,31:36),[],2);
%     filter_response_MR8(:,7:8) = filter_response(:,37:38);
%     filter_response = filter_response_MR8;
% end
filter_response=normalise(filter_response);
L = sum(filter_response' .^2)';
L = sqrt(L);
sc = log(1 + L / 0.03);
numerator = bsxfun(@times,filter_response,sc);
filter_response = bsxfun(@rdivide,numerator,L);
%filter_responseTotal=[filter_responseTotal,filter_response];
%end
return
function f=normalise(f), f=f-mean(f(:)); f=f/sum(abs(f(:))); 
return



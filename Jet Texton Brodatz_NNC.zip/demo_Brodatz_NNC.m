clc
clear all;
close all;

addpath(genpath('classification_toolbox_4.0'))
rootpath = 'C:\Users\dipakpc\Desktop\Sidd\Jet Texton Brodatz_NNC\Brodatz32\'
patch_width = -1;
patch_height = -1;
training_Dataset = [];

run('C:\Users\dipakpc\Desktop\Sidd\Jet Texton Brodatz_NNC\vlfeat-0.9.20-bin\vlfeat-0.9.20\toolbox\vl_setup');

no_classes = 32; %% Should be 61. This is the number of classes you are going to used during the modeling and classification phase
no_training_classes = 32; %% Should be 20. This is the number of classes you are going to used during the texton dictionary phase
training_classes = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32];

total_images_per_class = 64; %% Total number of images per texture class
training_per_class = 32; %% Number of images used per texture to build histogram models
test_per_class = total_images_per_class-training_per_class; %% Number of images used per texture to be classified

%% Specify the filter to be used.
%filter_bank  = makeLMfilters; %%  to use LM Filter bank
%filter_bank  = makeSfilters; %%  to use S Filter bank

filter_bank = makeRFSfilters; %%  to use RFS Filter bank
training_options = 'MR8'; %% To indicate that you are going to extract the MR-8 from RFS repos.
classification_options = 'MR8';

numOfFilters = size(filter_bank,3);
if strfind(training_options, 'MR8')
    % need to modify according to the number of response
    numOfFilters = 6;
end


KNN = 1;


numClustersPerClass = 15;
NUM_BINS = numClustersPerClass * no_classes;

total_images = cell(total_images_per_class,no_training_classes);

% 
% for c=1:no_training_classes
%     i = training_classes(c); 
%     folderPath = [rootpath sprintf('%02d',i) '/'];
%     filenames = [fuf(folderPath ,'detail')]; 
%     total_images(1:total_images_per_class,c) = filenames(1:total_images_per_class ,:);
% end

classes = 1:no_classes;
training_images = cell(training_per_class,no_classes);
test_images = cell(test_per_class,no_classes);
total_images = cell(total_images_per_class,no_classes);
for c=1:no_classes
    i = classes(c); 
    folderPath = [rootpath sprintf('%02d',i) '/'];
    filenames = [fuf(folderPath ,'detail')]; 
    total_images(1:total_images_per_class,c) = filenames(1:total_images_per_class ,:);
    
    %% Taking images by order
    %training_images(1:training_per_class ,c) = filenames(1:training_per_class ,:);
    %test_images(1:test_per_class,c) = filenames(training_per_class+1:total_images_per_class,:);
    
    %% Alternative images
    %training_images(1:training_per_class ,c) = filenames(1:2:total_images_per_class ,:);
    %test_images(1:test_per_class,c) = filenames(2:2:total_images_per_class,:);
    
    perm = randperm(total_images_per_class);
    sel = perm(1:training_per_class);
    %% Random Images
    training_images(1:training_per_class ,c) = filenames(sel);
    test_images(1:test_per_class,c) = filenames(setdiff(1:total_images_per_class,sel));
end




params = {};
params.numOfFilters = numOfFilters;
params.numClustersPerClass = numClustersPerClass;
params.no_training_classes = no_training_classes;
params.patch_width = patch_width;
params.patch_height = patch_height;
params.filter_bank = filter_bank;
params.training_options = training_options;
params.training_per_class = training_per_class;
params.training_images = training_images;

[ training_class_centroid ] = build_texton_dictionary( params );

params = {};
params.patch_width = patch_width;
params.patch_height = patch_height;
params.filter_bank = filter_bank;
params.training_options = training_options;
params.training_images = training_images;
params.training_class_centroid = training_class_centroid;
params.NUM_BINS = NUM_BINS;
params.training_per_class = training_per_class;
params.no_classes = no_classes;

[ training_histogram,training_classes ] = build_histogram_models( params);


params = {};
params.patch_width = patch_width;
params.patch_height = patch_height;
params.filter_bank = filter_bank;
params.classification_options = classification_options;
params.training_class_centroid = training_class_centroid;
params.NUM_BINS = NUM_BINS;
params.no_classes = no_classes;
params.training_histogram = training_histogram;
params.training_classes = training_classes;
params.test_images = test_images;
params.test_per_class = test_per_class;
params.KNN = KNN;
[test_histogram,test_classes, accuracy ] = classify_images_NNC( params );

figure;
% imagesc(accuracy);
mean(diag(accuracy) * 100 / test_per_class)
per_class_accuracy = diag(accuracy) * 100 / test_per_class;
Acc1=(accuracy * 100)/test_per_class;
imagesc(Acc1);
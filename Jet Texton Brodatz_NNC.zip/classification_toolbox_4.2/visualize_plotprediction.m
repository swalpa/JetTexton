function visualize_plotprediction(model)

% plots class boundaries for 2D datasets or for models calibrated on 2 components
%
% The main routine is class_gui
%
% Note that a detailed HTML help is provided with the toolbox.
% See the HTML HELP files (help.htm) for futher details and examples
%
% Classification toolbox for MATLAB
% version 4.2 - January 2016
% Davide Ballabio
% Milano Chemometrics and QSAR Research Group
% http://michem.disat.unimib.it/chm/

if strcmp(model.type,'plsda') % if model was calibrated on components
    if size(model.T,2) == 2 % on 2 PCs
        X = model.T; % data to be predicted
        [x,y,Xgrid] = makegriddata(X,500);
        Xplot = X; % data to be plotted
        Xgrid_plot = Xgrid;
        variable_labels{1} = 'scores on LV1';
        variable_labels{2} = 'scores on LV2';
    else % on 2D data with 1 PCs
        X = model.settings.raw_data;
        [x,y,Xgrid] = makegriddata(X,100);
        Xplot = data_pretreatment(X,model.settings.pret_type);
        Xgrid_plot = test_pretreatment(Xgrid,model.settings.px);
        variable_labels = getlabels(model);
    end
elseif strcmp(model.type,'pcalda') || strcmp(model.type,'pcaqda')
    if size(model.settings.modelpca.T,2) == 2 % on 2 PCs
        X = model.settings.modelpca.T;
        [x,y,Xgrid] = makegriddata(X,500);
        Xplot = X;
        Xgrid_plot = Xgrid;
        variable_labels{1} = 'scores on PC1';
        variable_labels{2} = 'scores on PC2';
    else % on 2D data with 1 PCs
        X = model.settings.raw_data;
        [x,y,Xgrid] = makegriddata(X,250);
        Xplot = data_pretreatment(X,model.settings.pret_type);
        Xgrid_plot = test_pretreatment(Xgrid,model.settings.modelpca.settings.param);
        variable_labels = getlabels(model);
    end
elseif strcmp(model.type,'knn') || strcmp(model.type,'simca') % if model was calibrated on scaled data
    X = model.settings.raw_data;
    if strcmp(model.type,'knn')
        [x,y,Xgrid] = makegriddata(X,50);
    else
        [x,y,Xgrid] = makegriddata(X,150);
    end
    [Xplot,param_simca] = data_pretreatment(X,model.settings.pret_type);
    Xgrid_plot = test_pretreatment(Xgrid,param_simca);
    variable_labels = getlabels(model);
elseif strcmp(model.type,'svm') || strcmp(model.type,'pf') % special cases for svm and pf, data or components
    if isstruct(model.settings.model_pca) && model.settings.num_comp == 2
        X = model.settings.model_pca.T; % data to be predicted
        [x,y,Xgrid] = makegriddata(X,100);
        Xplot = X; % data to be plotted
        Xgrid_plot = Xgrid;
        variable_labels{1} = 'scores on PC1';
        variable_labels{2} = 'scores on PC2';
    else % on 2D data with 1 PCs
        X = model.settings.raw_data;
        [x,y,Xgrid] = makegriddata(X,100);
        [Xplot,param_svmpotfun] = data_pretreatment(X,model.settings.pret_type);
        Xgrid_plot = test_pretreatment(Xgrid,param_svmpotfun);
        variable_labels = getlabels(model);
    end
else % cart, lda, qda
    X = model.settings.raw_data;
    Xplot = X;
    [x,y,Xgrid] = makegriddata(X,500);
    Xgrid_plot = Xgrid;
    variable_labels = getlabels(model);
end

% make prediction on grid data
if strcmp(model.type,'plsda')
    if size(model.T,2) == 2 % on 2 PCs
        Q = model.Q;
        nF = size(model.T,2);
        yscal_c = 0;
        for k = 1:nF
            yscal_c = yscal_c + Xgrid(:,k)*Q(:,k)';
        end
        yc = redo_scaling(yscal_c,model.settings.py);
    else
        pred = plsdapred(Xgrid,model);
        yc = pred.yc;
    end
    if strcmp(model.settings.assign_method,'max')
        [non,assigned_class] = max(yc');
    else
        assigned_class = plsdafindclass(yc,model.settings.thr);
    end
    class_pred = assigned_class';
    P = reshape(class_pred, [length(x) length(y)]);
elseif strcmp(model.type,'pcalda') || strcmp(model.type,'pcaqda')
    if size(model.settings.modelpca.T,2) == 2
        if model.settings.class_prob == 1
            class_pred = classify(Xgrid,X,model.settings.class,model.settings.method);
        else
            class_pred = classify(Xgrid,X,model.settings.class,model.settings.method,model.settings.prob);
        end
    else
        if model.settings.class_prob == 1
            pred = dapred(Xgrid,model);
            class_pred = pred.class_pred;
        else
            pred = dapred(Xgrid,model);
            class_pred = pred.class_pred;
        end
    end
    P = reshape(class_pred, [length(x) length(y)]);
elseif strcmp(model.type,'lda') || strcmp(model.type,'qda')
    pred = dapred(Xgrid,model);
    P = reshape(pred.class_pred, [length(x) length(y)]);
elseif strcmp(model.type,'knn') 
    pred = knnpred(Xgrid,model.settings.raw_data,model.settings.class,model.settings.K,model.settings.dist_type,model.settings.pret_type);
    P = reshape(pred.class_pred, [length(x) length(y)]);
elseif strcmp(model.type,'simca')
    pred = simcapred(Xgrid,model);
    for g=1:max(model.settings.class)
        P{g} = reshape(pred.settings.binary_assignation(:,g), [length(x) length(y)]);
    end
elseif strcmp(model.type,'svm')
    if isstruct(model.settings.model_pca) && model.settings.num_comp == 2
        [~,dist] = predict(model.settings.net,Xgrid);
        dist = dist(:,2);
    else % on 2D data with 1 PCs
        pred = svmpred(Xgrid,model);
        dist = pred.dist;
    end
    P = reshape(dist, [length(x) length(y)]);
elseif strcmp(model.type,'pf')
    if isstruct(model.settings.model_pca) && model.settings.num_comp == 2
        for g=1:length(model.settings.Xclass)
            for i=1:size(Xgrid,1)
                phere(i,g) = potcalc(Xgrid(i,:),model.settings.Xclass{g},model.settings.type,model.settings.smoot(g));
            end
        end
    else
        pred = potpred(Xgrid,model);
        phere = pred.P;
    end
    for g=1:length(model.settings.Xclass)
        P{g} = reshape(phere(:,g), [length(x) length(y)]);
    end
else % cart
    pred = cartpred(Xgrid,model);
    P = reshape(pred.class_pred, [length(x) length(y)]);
end

% plot areas
class = model.settings.class;
col_ass = visualize_colors;
figure
set(gcf,'color','white');
hold on
xx = reshape(Xgrid_plot(:,1), [length(x) length(y)]);
yy = reshape(Xgrid_plot(:,2), [length(x) length(y)]);
if strcmp(model.type,'svm')
    contour(xx, yy, P, [1 1], 'b-');
    contour(xx, yy, P, [-1 -1], 'r-');
    contour(xx, yy, P, [0 0], 'k-');
elseif strcmp(model.type,'pf')
    for g=1:length(model.settings.Xclass)
        contour(xx, yy, P{g}, [model.settings.thr(g) model.settings.thr(g)], 'LineColor', col_ass(g+1,:));
    end
elseif strcmp(model.type,'simca')
    for g=1:max(model.settings.class)
        contour(xx, yy, P{g}, [1 1], 'LineColor', col_ass(g+1,:));
    end
else % plsda, lda, qda, pcalda, pcaqda, knn, cart with predicted class labels
    draw_class = zeros(max(class),1);
    for g=1:max(class)
        Ptmp = P;
        Ptmp(find(P~=g)) = 0;
        Ptmp(find(P==g)) = g;
        if length(find(Ptmp>0)) > 0
            % do contourface if samples are assigned to the class
            % e.g. 2 PC scores on Iris, PLSDA 1 LVs, bayes assignation, class
            % 3 is not assigned at all
            contourf(xx, yy, Ptmp, [g g]);
            draw_class(g) = 1;
        end
    end
    colormap(col_ass(find(draw_class) + 1,:))
end

% plot samples and sv
if strcmp(model.type,'svm')
    for g=1:max(class)
        inclass = find(class==g);
        a = find(class(model.svind)==g);
        svinclass = model.svind(a);
        plot(Xplot(inclass,1),Xplot(inclass,2),'o','MarkerEdgeColor',col_ass(g+1,:),'MarkerSize',5,'MarkerFaceColor','w')
        plot(Xplot(svinclass,1),Xplot(svinclass,2),'o','MarkerEdgeColor','k','MarkerSize',5,'MarkerFaceColor',col_ass(g+1,:))
    end
else
    for g=1:max(class)
        inclass = find(class==g);
        color_in = col_ass(g+1,:);
        plot(Xplot(inclass,1),Xplot(inclass,2),'o','MarkerEdgeColor','k','MarkerSize',5,'MarkerFaceColor',color_in)
    end
end

% plot errors
% err = find(model.class_calc ~= model.settings.class);
% plot(Xplot(err,1),Xplot(err,2),'*','MarkerEdgeColor','k','MarkerSize',3,'MarkerFaceColor','k')

% labels and plot settings
xlabel(variable_labels{1})
ylabel(variable_labels{2})
box on
hold off

%---------------------------------------------------
function [x,y,Xgrid] = makegriddata(X,step)
% make grid
rx = (max(X(:,1)) - min(X(:,1)));
ry = (max(X(:,2)) - min(X(:,2)));
xrange = [min(X(:,1))-rx/5 max(X(:,1))+rx/5];
yrange = [min(X(:,2))-ry/5 max(X(:,2))+ry/5];
x = xrange(1):(xrange(2)-xrange(1))/step:xrange(2);
y = yrange(1):(yrange(2)-yrange(1))/step:yrange(2);
[xx,yy] = meshgrid(x,y);
Xgrid = [xx(:),yy(:)];

%---------------------------------------------------
function variable_labels = getlabels(model)
if length(model.labels.variable_labels) > 0
    variable_labels = model.labels.variable_labels;
else
    for k=1:size(model.settings.raw_data,2); variable_labels{k} = ['variable ' num2str(k)]; end
end

function [ training_class_centroid ] = build_texton_dictionary( params )

numOfFilters = params.numOfFilters;
numClustersPerClass = params.numClustersPerClass;
no_training_classes = params.no_training_classes;
patch_width = params.patch_width;
patch_height = params.patch_height;
filter_bank = params.filter_bank;
training_options = params.training_options;
training_per_class = params.training_per_class;
training_images = params.training_images;

training_class_centroid = zeros(numClustersPerClass * no_training_classes,numOfFilters);
for i=1:no_training_classes
   
    training_filter_response = [];
    fprintf('Start: training class %d\n',i);
    perm = randperm(training_per_class);
%     sel = perm(1:13);
%     for j=1:13
     
 if training_per_class<=20
    sel = perm(1:training_per_class);
    for j=1:training_per_class
        image_name = training_images{sel(j),i};
        filter_response = im2filter_response( image_name,patch_width,patch_height,filter_bank,training_options);
        training_filter_response = [training_filter_response;filter_response]; 
    end
else
    sel = perm(1:20);
    for j=1:20
        image_name = training_images{sel(j),i};
        filter_response = im2filter_response( image_name,patch_width,patch_height,filter_bank,training_options);
        training_filter_response = [training_filter_response;filter_response]; 
    end
end
    
    start = (i-1)*numClustersPerClass+1;
    count = numClustersPerClass-1;
    
    
    [centers, ~] = vl_kmeans(training_filter_response', numClustersPerClass);
    training_class_centroid(start:start+count,:) = centers';
    
    %opts = statset('MaxIter',200);
    %[assignments,centers] = kmeans(training_filter_response, numClustersPerClass,'Options',opts,'Replicates',2);
    %training_class_centroid(start:start+count,:) = centers;
    fprintf('End: training class %d\n',i);
   
end

end


function DtGkernels = DtGfiltersBankHigh(sigma,configuration)
% DTGFILTERSBANK Generates the Derivative-of-Gaussian (DtG) kernels for the computation of
% BIFs. 

if(nargin<2)
    configuration = 1;
end

x = -5*sigma:5*sigma;
xSquared = x.^2;

DtGkernels = cell(10,2);

% Use configuration 1 to get identical response to legacy method
if(configuration==1)
    
    baseKernel = exp(-xSquared./(2*sigma^2));
    dKernel{1} = (1/(sqrt(2)*sigma)).*baseKernel;
    dKernel{2} = -x.*(1/(sqrt(2)*sigma^3)).*baseKernel;
    dKernel{3} = (xSquared - sigma^2).*(1/(sqrt(2)*sigma^5)).*baseKernel;
    dKernel{4} = -x.*(xSquared - 3*sigma^2).*(1/(sqrt(2)*sigma^7)).*baseKernel;
    
    orders=[0, 0; 1, 0; 0, 1; 2, 0; 1, 1; 0, 2; 3, 0; 2, 1; 1, 2; 0, 3];
    
    for i=1:size(orders,1)
        DtGkernels{i,2} = dKernel{orders(i,1)+1};
        DtGkernels{i,1} = dKernel{orders(i,2)+1};
    end
    
else
    
    % Compute the 0,0 order kernel
    G=fspecial('gaussian',[numel(x), numel(x)], sigma);
    
    % Compute the 1,0 and 0,1 order kernels
    [Gx,Gy] = gradient(G);
    
    % Compute the 2,0, 1,1 and 0,2 order kernels
    [Gxx,Gxy] = gradient(Gx);
    [Gyx,Gyy] = gradient(Gy);
    
    DtGkernels{1} = G;
    DtGkernels{3} = Gx;
    DtGkernels{2} = Gy;
    DtGkernels{6} = Gxx;
    DtGkernels{5} = Gxy;
    DtGkernels{4} = Gyy;
end
end

